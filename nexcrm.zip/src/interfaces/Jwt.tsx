
export interface Jwt  

{
    "_id": string;
    "isBusiness": boolean;
    "isAdmin": boolean;
    "iat": number
  }