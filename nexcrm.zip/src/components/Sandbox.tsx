import { FunctionComponent } from "react";

interface SandboxProps {
    
}
 
const Sandbox: FunctionComponent<SandboxProps> = () => {
    return (<>

<h1>sandbox</h1>

    </>);
}
 
export default Sandbox;